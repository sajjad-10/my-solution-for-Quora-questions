import React from 'react'

const UserList = () => {
   return(<div></div>)
}

export default UserList
